
var app = {
	url : "https://github.com/nikn/autoUpdater/www.zip",
	// Application Constructor
	initialize: function() {
		this.bindEvents();
	},
	// Bind Event Listeners

	bindEvents: function() {
		document.addEventListener('deviceready', this.onDeviceReady, false);
	},

	onDeviceReady: function() {
		app.receivedEvent('deviceready');
	},

	receivedEvent: function(id) {
		var parentElement = document.getElementById(id);
		var listeningElement = parentElement.querySelector('.listening');
		var receivedElement = parentElement.querySelector('.received');

		listeningElement.setAttribute('style', 'display:none;');
		receivedElement.setAttribute('style', 'display:block;');

		console.log('Received Event: ' + id);

		document.getElementById("syncBtn").onclick = this.sync;
		document.getElementById("downloadExtractBtn").onclick = this.download;
	},

	setProgress: function(progress) {
		if(progress.status) {
			switch(progress.status) {
				case 1:
					document.getElementById('status').innerHTML = "Downloading...";
					break;
				case 2:
					document.getElementById('status').innerHTML = "Extracting...";
					break;
				case 3:
					document.getElementById('status').innerHTML = "Complete!";
					break;
				default:
					document.getElementById('status').innerHTML = "";
			}
		}
		if(progress.progress) {
			var progressBar = document.getElementById('progressbar').children[0];
			progressBar.style.width = progress.progress + '%';
		}
	},


	sync: function() {

		var sync = ContentSync.sync({ src: this.url, id: 'myapp', type: 'merge', copyRootApp: true });

		var setProgress = this.setProgress;

		sync.on('progress', function(progress) {
			console.log("Progress event", progress);
			app.setProgress(progress);
		});
		sync.on('complete', function(data) {
			console.log("Complete", data);
		});

		sync.on('error', function(e) {
			console.log("Something went wrong: ", e);
			document.getElementById('status').innerHTML = e;
		});
	},
	download: function() {
		document.getElementById("downloadExtractBtn").disabled = true;
		var extract = this.extract;
		var setProgress = this.setProgress;
		var callback = function(response) {
			console.log(response);
			if(response.progress) {
				app.setProgress(response);

			}
			if(response.localPath) {
				var archiveURL = response.localPath;
				document.getElementById("downloadExtractBtn").disabled = false;
				document.getElementById("downloadExtractBtn").innerHTML = "Extract";
				document.getElementById("downloadExtractBtn").onclick = function() {
					app.extract(archiveURL);
				};
				document.getElementById("status").innerHTML = archiveURL;
			}
		};
		ContentSync.download(this.url, callback);
	},
	extract: function(archiveURL) {
		window.requestFileSystem(PERSISTENT, 1024 * 1024, function(fs) {
			fs.root.getDirectory('zipOutPut', {create: true}, function(fileEntry) {
				var dirUrl = fileEntry.toURL();
				var callback = function(response) {
					console.log(response);
					document.getElementById("downloadExtractBtn").style.display = "none";
					document.getElementById("status").innerHTML = "Extracted";
				}
				console.log(dirUrl, archiveURL);
				Zip.unzip(archiveURL, dirUrl, callback);
			});
		});
	}
};

app.initialize();